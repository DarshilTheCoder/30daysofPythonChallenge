from pydantic import BaseModel, Field, field_validator

class BookCreate(BaseModel):
    book_name: str = Field(description='Name of the book')
    author_name: str = Field(description='Name of the author of the book')
    publication_year: int = Field(description='Publication year of the book')

    @field_validator('publication_year')
    @classmethod
    def checking_publication_year(cls, year_value):
        if not (1000 <= year_value <= 9999):
            raise ValueError('Year must be of 4 digits only')
        return year_value

class BookOut(BaseModel):
    book_id: int
    book_name: str
    author_name: str
    publication_year: int

    model_config = {
        "from_attributes": True
    }
