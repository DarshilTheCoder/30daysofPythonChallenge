from sqlalchemy import Column, Integer, String
from database import Base

class Library(Base):
    __tablename__ = 'Library'

    book_id = Column(Integer, primary_key=True, index=True)
    book_name = Column(String(100))
    author_name = Column(String(100))
    publication_year = Column(Integer)
