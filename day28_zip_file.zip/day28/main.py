from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
from typing import List
import models, schemas, database

models.Base.metadata.create_all(bind=database.engine)
app = FastAPI()
# Dependency to get database session
def get_db():
    db = database.SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.get('/book_info', response_model=List[schemas.BookOut])
async def get_books(db: Session = Depends(get_db)):
    books = db.query(models.Library).all()
    return books

@app.post('/book_info')
async def add_book(book: schemas.BookCreate, db: Session = Depends(get_db)):
    new_book = models.Library(
        book_name=book.book_name,
        author_name=book.author_name,
        publication_year=book.publication_year
    )
    db.add(new_book)
    db.commit()
    db.refresh(new_book)
    return {"message": "Book added successfully", "book info": book}

@app.put('/book_info')
async def update_book(book_id: int, updated_book: schemas.BookCreate, db: Session = Depends(get_db)):
    book = db.query(models.Library).filter(models.Library.book_id == book_id).first()
    if not book:
        return {"message": "Book not found, kindly add it first"}

    book.book_name = updated_book.book_name
    book.author_name = updated_book.author_name
    book.publication_year = updated_book.publication_year

    db.commit()
    db.refresh(book)
    return {"message": "Book updated successfully", "book": updated_book}

@app.delete('/book_info')
async def delete_book(book_id: int, db: Session = Depends(get_db)):
    book = db.query(models.Library).filter(models.Library.book_id == book_id).first()
    if book is None:
        return {"message": "Book not found", "book_id": book_id}
    db.delete(book)
    db.commit()
    return {"message": "Book deleted successfully", "book_id": book_id}
